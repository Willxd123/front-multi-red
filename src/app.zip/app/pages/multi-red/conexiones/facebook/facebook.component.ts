import { Component } from '@angular/core';

@Component({
  selector: 'app-facebook',
  standalone: true,
  imports: [],
  templateUrl: './facebook.component.html',
  styleUrl: './facebook.component.css'
})
export class FacebookComponent {

}
