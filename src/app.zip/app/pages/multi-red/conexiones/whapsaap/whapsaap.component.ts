import { Component } from '@angular/core';

@Component({
  selector: 'app-whapsaap',
  standalone: true,
  imports: [],
  templateUrl: './whapsaap.component.html',
  styleUrl: './whapsaap.component.css'
})
export class WhapsaapComponent {

}
