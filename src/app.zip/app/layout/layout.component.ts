import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SidebarComponent } from "./components/sidebar/sidebar.component";
import { NavbarComponent } from "./components/navbar/navbar.component";
import { CommonModule } from '@angular/common';
// Importamos FormsModule para [(ngModel)]
import { FormsModule } from '@angular/forms'; 
// Importamos el servicio y modelos (Asumiendo que existen)
import { ChatbotService, ChatbotResponse } from '../services/chatbot.service'; 


// Interfaces para la estructura de la respuesta de la API
interface SocialMediaResponse {
  text: string;
  character_count: number;
  suggested_image_prompt?: string;
}

// Interfaz para el historial de mensajes (unificamos la respuesta de la API)
interface Message {
  id: number;
  sender: 'user' | 'chatbot';
  text: string;
  response?: ChatbotResponse; // Solo para mensajes del chatbot
}

@Component({
  selector: 'app-layout',
  standalone: true,
  // ⬅️ Agregamos FormsModule para el input y el binding
  imports: [SidebarComponent, NavbarComponent, CommonModule, FormsModule], 
  templateUrl: './layout.component.html'
})
export class LayoutComponent implements OnInit {
  @ViewChild(SidebarComponent) sidebar!: SidebarComponent;
  
  isSidebarOpen = true;
  activeConversationId: number | null = null;
  
  // ⬅️ Nuevas propiedades para el chat
  messages: Message[] = []; // Historial de mensajes
  currentPrompt: string = ''; // El texto actual en el textarea
  isLoading: boolean = false; // Estado de carga para el botón de envío
  private messageIdCounter = 0;
  
  // Array para iterar en la vista de la respuesta
  socialNetworks = ['Facebook', 'Instagram', 'LinkedIn', 'TikTok', 'WhatsApp'];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    // ⬅️ Inyectamos el servicio del chatbot
    private chatbotService: ChatbotService 
  ) {}

  ngOnInit(): void {
    this.checkScreenSize();
    this.loadConversationFromRoute();
    this.loadInitialMessages(); // Cargar el historial que estaba en el HTML
  }

  /**
   * Cargar el historial que estaba previamente en el HTML
   */
  loadInitialMessages(): void {
    // Reemplazado con un historial inicial más simple o vacío
    this.messages = [
      { id: 1, sender: 'user', text: 'Hola, necesito generar contenido para mis redes sociales.' },
      { id: 2, sender: 'chatbot', text: '¡Claro! Solo dime el evento o la idea principal (el prompt) y te generaré textos optimizados para Facebook, Instagram, LinkedIn, TikTok y WhatsApp.' },
    ];
    this.messageIdCounter = 2;
    setTimeout(() => this.scrollToBottom(), 0);
  }

  /**
   * ⬅️ Método principal para enviar el mensaje y llamar a la API
   */
  sendMessage(): void {
    const prompt = this.currentPrompt.trim();
    if (!prompt || this.isLoading) {
      return;
    }

    this.isLoading = true;

    // 1. Agregar el mensaje del usuario al historial
    this.messages.push({
      id: ++this.messageIdCounter,
      sender: 'user',
      text: prompt,
    });

    // Resetear el input e intentar scrollear antes de la respuesta
    this.currentPrompt = '';
    setTimeout(() => this.scrollToBottom(), 0);

    // 2. Llamar al servicio (asumiendo que ChatbotService tiene generateSocialMediaContent)
    this.chatbotService.generateSocialMediaContent(prompt).subscribe({
      next: (response) => {
        // 3. Agregar la respuesta del chatbot al historial
        this.messages.push({
          id: ++this.messageIdCounter,
          sender: 'chatbot',
          text: '¡Contenido generado para tus redes!',
          response: response as ChatbotResponse, // Asegurar el tipo
        });
        this.isLoading = false;
        setTimeout(() => this.scrollToBottom(), 0);
      },
      error: (err) => {
        console.error('Error al generar contenido:', err);
        this.messages.push({
          id: ++this.messageIdCounter,
          sender: 'chatbot',
          text: 'Ocurrió un error al generar el contenido. Inténtalo de nuevo.',
        });
        this.isLoading = false;
        setTimeout(() => this.scrollToBottom(), 0);
      }
    });
  }
  
  /**
   * ⬅️ Método para hacer scroll automático al final del área de chat
   */
  scrollToBottom(): void {
    const element = document.querySelector('.chat-area');
    if (element) {
      element.scrollTop = element.scrollHeight;
    }
  }

  // *** Métodos existentes (sin modificar, solo se mantiene el orden) ***
  loadConversationFromRoute(): void {
    // ... (Lógica original)
    this.route.params.subscribe(params => {
      const id = params['conversationId'];
      if (id) {
        this.activeConversationId = +id;
        console.log('📂 Conversación cargada desde URL:', this.activeConversationId);
      } else {
        this.activeConversationId = null;
        console.log('🆕 Sin conversación activa');
      }
    });
  }

  toggleSidebar(): void {
    this.isSidebarOpen = !this.isSidebarOpen;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: Event): void {
    this.checkScreenSize();
  }

  private checkScreenSize(): void {
    if (window.innerWidth < 1024) {
      this.isSidebarOpen = false;
    } else {
      this.isSidebarOpen = true;
    }
  }

  onNewConversation(conversationId: number): void {
    if (conversationId === 0) {
      this.router.navigate(['/chat']);
      console.log('🗑️ Conversación eliminada, navegando a chat vacío');
    } else {
      this.router.navigate(['/chat', conversationId]);
      console.log('🆕 Navegando a nueva conversación:', conversationId);
    }
  }

  onConversationSelected(conversationId: number): void {
    this.router.navigate(['/chat', conversationId]);
    console.log('📂 Navegando a conversación:', conversationId);
  }

  onConversationCreated(conversationId: number): void {
    this.router.navigate(['/chat', conversationId], { replaceUrl: true });
    console.log('✅ Conversación actualizada:', conversationId);
    
    if (this.sidebar) {
      this.sidebar.loadConversations();
    }
  }
}