import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environment';


// Define las interfaces para tipar la respuesta
interface SocialMediaResponse {
  text: string;
  character_count: number;
  suggested_image_prompt?: string;
}

export interface ChatbotResponse {
  Facebook: SocialMediaResponse;
  Instagram: SocialMediaResponse;
  LinkedIn: SocialMediaResponse;
  TikTok: SocialMediaResponse;
  WhatsApp: SocialMediaResponse;
  [key: string]: SocialMediaResponse; 

}

@Injectable({
  providedIn: 'root'
})
export class ChatbotService {
  private apiUrl = `${environment.apiUrl}/chatbot/redes`;

  constructor(private http: HttpClient) { }

  /**
   * Genera el contenido para las redes sociales basado en un prompt.
   * @param prompt El texto de entrada del usuario.
   * @returns Un Observable con la respuesta del chatbot.
   */
  generateSocialMediaContent(prompt: string): Observable<ChatbotResponse> {
    const body = { prompt: prompt };
    return this.http.post<ChatbotResponse>(this.apiUrl, body);
  }
}