import { Component } from '@angular/core';

@Component({
  selector: 'app-linkedin',
  standalone: true,
  imports: [],
  templateUrl: './linkedin.component.html',
  styleUrl: './linkedin.component.css'
})
export class LinkedinComponent {

}
