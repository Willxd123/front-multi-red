import { Component } from '@angular/core';

@Component({
  selector: 'app-instagram',
  standalone: true,
  imports: [],
  templateUrl: './instagram.component.html',
  styleUrl: './instagram.component.css'
})
export class InstagramComponent {

}
