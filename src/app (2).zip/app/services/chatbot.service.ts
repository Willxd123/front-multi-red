import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// --- Interfaces basadas en tu Backend ---

export interface MediaInfo {
  tipo?: string;
  descripcion?: string;
  guion?: string;
  ruta?: string;
  fileName?: string;
}

export interface SocialNetworkContent {
  media_info?: MediaInfo;
}

export interface MessageContent {
  text?: string; // Para el usuario
  // Para el asistente (pueden venir varias redes)
  TikTok?: SocialNetworkContent;
  Facebook?: SocialNetworkContent;
  Instagram?: SocialNetworkContent;
  LinkedIn?: SocialNetworkContent;
  WhatsApp?: SocialNetworkContent;
  status?: 'processing_media' | 'completed' | 'error';
}

export interface Message {
  id: number;
  role: 'user' | 'assistant';
  content: MessageContent;
  createdAt: string;
}

export interface ConversationDetail {
  id: number;
  messages: Message[];
}

@Injectable({
  providedIn: 'root'
})
export class ChatbotService {
  // Ajusta la URL base si es necesario
  private apiUrl = 'http://localhost:3000/api'; 

  constructor(private http: HttpClient) {}

  /**
   * 1. Enviar el prompt (POST)
   * Ignoramos la respuesta para renderizar, solo nos importa que se envíe.
   */
  sendMessage(prompt: string, conversationId: number): Observable<any> {
    const body = { 
      prompt: prompt,
      conversationId: conversationId 
    };
    return this.http.post(`${this.apiUrl}/chatbot/redes`, body);
  }

  /**
   * 2. Obtener el historial completo (GET)
   * Esto es lo que usaremos para pintar el chat.
   */
  getConversationHistory(conversationId: number): Observable<ConversationDetail> {
    return this.http.get<ConversationDetail>(`${this.apiUrl}/conversations/${conversationId}`);
  }
}