import { Component, OnInit, OnDestroy, HostListener, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SidebarComponent } from "./components/sidebar/sidebar.component";
import { NavbarComponent } from "./components/navbar/navbar.component";
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; 
import { ChatbotService } from '../services/chatbot.service'; 
// Importamos Subscription e interval para el polling (actualización automática)
import { Subscription, interval } from 'rxjs';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [SidebarComponent, NavbarComponent, CommonModule, FormsModule], 
  templateUrl: './layout.component.html'
})
export class LayoutComponent implements OnInit, OnDestroy {
  @ViewChild(SidebarComponent) sidebar!: SidebarComponent;
  
  isSidebarOpen = true;
  
  // ⬅️ ID Estático por el momento, según tu requerimiento
  activeConversationId: number = 5;
  
  // Propiedades del chat
  messages: any[] = []; // Usamos any[] o la interfaz Message que definas en el servicio
  currentPrompt: string = '';
  isLoading: boolean = false;
  
  // Para controlar la actualización automática (polling)
  private pollingSubscription: Subscription | null = null;
  
  // Array para iterar en la vista (coincide con las llaves de tu JSON de respuesta)
  socialNetworks = ['TikTok', 'Facebook', 'Instagram', 'LinkedIn', 'WhatsApp'];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private chatbotService: ChatbotService 
  ) {}

  ngOnInit(): void {
    this.checkScreenSize();
    
    // 1. Cargar historial inicial de la conversación 5
    this.loadConversationMessages(true);

    // 2. Iniciar el polling para buscar actualizaciones de video/imagen automáticamente
    this.startPolling();
  }

  ngOnDestroy(): void {
    // 3. Limpiar el intervalo cuando se destruye el componente para evitar fugas de memoria
    this.stopPolling();
  }

  /**
   * Carga el historial completo desde la API
   * @param shouldScroll Si es true, baja el scroll al final (usado en carga inicial o al enviar)
   */
  loadConversationMessages(shouldScroll: boolean = false): void {
    if (!this.activeConversationId) return;

    this.chatbotService.getConversationHistory(this.activeConversationId).subscribe({
      next: (data) => {
        // Asumimos que tu endpoint retorna { messages: [...] } o el objeto de conversación con messages
        this.messages = data.messages || []; 
        
        if (shouldScroll) {
          setTimeout(() => this.scrollToBottom(), 100);
        }
      },
      error: (err) => {
        console.error('Error cargando mensajes:', err);
      }
    });
  }

  /**
   * Envía el mensaje y recarga la conversación
   */
  sendMessage(): void {
    const prompt = this.currentPrompt.trim();
    if (!prompt || this.isLoading) {
      return;
    }

    this.isLoading = true;
    // Limpiamos el input inmediatamente para mejor UX
    this.currentPrompt = ''; 

    // Llamada al endpoint POST
    this.chatbotService.sendMessage(prompt, this.activeConversationId).subscribe({
      next: () => {
        // Una vez enviado, recargamos el historial para ver el mensaje del usuario 
        // y el mensaje "processing" del asistente.
        this.loadConversationMessages(true);
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error al enviar mensaje:', err);
        this.isLoading = false;
      }
    });
  }

  /**
   * Inicia la actualización automática cada 4 segundos
   * Esto sirve para que cuando el backend termine de crear el video,
   * el frontend lo muestre sin recargar la página.
   */
  startPolling(): void {
    this.pollingSubscription = interval(4000).subscribe(() => {
      // Llamamos a cargar mensajes en silencio (sin forzar scroll si el usuario está leyendo arriba)
      this.loadConversationMessages(false);
    });
  }

  stopPolling(): void {
    if (this.pollingSubscription) {
      this.pollingSubscription.unsubscribe();
    }
  }
  
  scrollToBottom(): void {
    const element = document.querySelector('.chat-area');
    if (element) {
      element.scrollTop = element.scrollHeight;
    }
  }

  // *** Métodos de UI (Sidebar, Resize, etc.) ***

  toggleSidebar(): void {
    this.isSidebarOpen = !this.isSidebarOpen;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: Event): void {
    this.checkScreenSize();
  }

  private checkScreenSize(): void {
    if (window.innerWidth < 1024) {
      this.isSidebarOpen = false;
    } else {
      this.isSidebarOpen = true;
    }
  }

  // Métodos placeholder para mantener la funcionalidad del sidebar si se expande a futuro
  onNewConversation(conversationId: number): void {
    console.log('Nueva conversación solicitada (lógica pendiente):', conversationId);
    // Aquí podrías cambiar el this.activeConversationId y recargar
  }

  onConversationSelected(conversationId: number): void {
    console.log('Conversación seleccionada:', conversationId);
    // Aquí podrías cambiar el this.activeConversationId y recargar
    // this.activeConversationId = conversationId;
    // this.loadConversationMessages(true);
  }
}